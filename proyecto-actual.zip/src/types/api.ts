export * from "@/src/tipos";
